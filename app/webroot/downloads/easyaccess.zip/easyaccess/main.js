$(document).ready(function(){
	settings = getSettings();
	$('#save_btn').click(function(){
    shortcut = $('#key').val();
    url = $('#value').val();
    newItem = {
	shortcut: url
	};
	
	var _remove = $('<a></a>')
			.css("padding-left", 20)
			.attr("href", "")
			.text("remove")
			.bind({
				click: function(e){
				var port = chrome.extension.connect({name: "openPanel"});
				var a = $(this);
   				var li = a.closest('li');
				port.postMessage({message: "remove", shortcut: li.children('.shortcut').text(), url: li.children('.url').text()});
				}
			});

	var _shortcut = $('<span></span>').addClass("shortcut")
			.text(shortcut)
			.css("padding-left", 20);

	var _url = $('<span></span>').addClass("url")
			.text(url)
			.css("padding-left", 20);

	var item = $('<li></li>')
	.append(_shortcut)
	.append(_url)
	.append(_remove)
	.prependTo('#saved ul');

	//messsage passing
	var port = chrome.extension.connect({name: "openPanel"});
	port.postMessage({message: "newShortcut", shortcut: shortcut, url: url});
	});

});

function getSettings(){
	var port = chrome.extension.connect({name: "openPanel"});
	port.postMessage({message: "getSettings"});
	port.onMessage.addListener(function(msg) {
		if (msg.message == "getSettings") {
			obj = msg.settings;
			for(item in obj) {
				var remove = $('<a></a>')
							.css("padding-left", 20)
							.text("remove")
							.attr("href", "")
							.bind({
								click: function(e) {
									var port = chrome.extension.connect({name: "openPanel"});
									var a = $(this);
   									var li = a.closest('li');
									port.postMessage({message: "remove", shortcut: li.children('.shortcut').text(), url: li.children('.url').text()});
								}
				
							});

				var _remove = $('<a></a>')
								.css("padding-left", 20)
								.text("remove")
								.attr("href", "")
								.bind({
									click: function(e){
										var port = chrome.extension.connect({name: "openPanel"});
										var a = $(this);
   										var li = a.closest('li');
										port.postMessage({message: "remove", shortcut: li.children('.shortcut').text(), url: li.children('.url').text()});
									}
								});

				var _shortcut = $('<span></span>').addClass("shortcut")
								.text(item)
								.css("padding-left", 20);

				var _url = $('<span></span>').addClass("url")
							.text(obj[item])
							.css("padding-left", 20);


				var entry = $('<li></li>')
							.append(_shortcut)
							.append(_url)
							.append(_remove)
            				.appendTo('#saved ul');
            			}
            settings = obj;
    	}
    });
}
