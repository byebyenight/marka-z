var HEADER_OPACITY = 0.9;
var CONTENT_OPACITY = 0.4;
var HIGHLIGHT_OPACITY = 0.9;
	
var url;
createPanel();
//$('.panel').draggable();
//$('.panel').resizable();
$('.panel').fadeIn(50, function() {
	var panel_height = $(this).height();
	// panel header
	var panel_header = $(this).children(".panel_header");
	$(this).children(".panel_content").css("height", panel_height);// - panel_header_height);
});

setTimeout(function(){
	$(".command").focus();
}, 500);

function createPanel() {
	var top = 0;
	var left = 0;
		
	var panel_width = 145; //Math.floor( screen.width / 8 );
	var panel_height = 45; //Math.floor( screen.height / 8 );
    
    var DHeader =
 				$("<div></div>").addClass("panel_header")
 				.css("opacity", HEADER_OPACITY)
				.append('<span>' +  "header" + '</span>');  
	var command = 
				$("<textarea></textarea>").addClass("command")
    			.attr("rows", 2)
    			.attr("cols", 15)
    			.bind({

    				keydown: function(e) {
    				var code = e.keyCode || e.which;
    				if(code == 13) { //Enter keycode
    					shortcut = $('textarea.command').val();
						console.log(shortcut+".....");
  						var port = chrome.extension.connect({name: "openPanel"});
						port.postMessage({message: "openTab", shortcut: shortcut});
					}
				}
			});


    var DContent =
				$("<div></div>").addClass("panel_content")
				.append(command)
				.css("opacity", CONTENT_OPACITY);


    $("<div></div").addClass("panel")
    .attr("id","draghere")
    .append(DContent)
    .css("top", 0)
	.css("left", 0)
    .css("width", panel_width)
    .css("height", panel_height)
    .appendTo("html");    
}
