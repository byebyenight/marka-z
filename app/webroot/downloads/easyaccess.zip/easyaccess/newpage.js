$(document).ready(function(){
	window.location.replace("https://www.google.com");
});