var KEY_ALT = 18;
var KEY_CTRL = 17;
var KEY_SHIFT = 16;
var openPanel = false;

chrome.browserAction.onClicked.addListener(function(tab) {	
  /*  chrome.tabs.executeScript(tab.id, {
            "file": "openPanel.js"
        }, function () { // Execute your code
            console.log("Script Executed .. "); // Notification on Completion
        });
    */
});
    
chrome.extension.onConnect.addListener(function(port) {
  port.onMessage.addListener(function(msg) {
    if (msg.message == 'openTab') {
      console.log("opentab"+"---"+msg.shortcut);
      var newURL = localStorage.getItem(msg.shortcut);
      chrome.tabs.create({ url: newURL});
    }
		else if (msg.message == 'newShortcut') {
      console.log("save" + msg.shortcut +" " + msg.url);
      localStorage.setItem(msg.shortcut, msg.url);
    }
    else if (msg.message == 'remove') {
      console.log("remove" + msg.shortcut + msg.url);
      localStorage.removeItem(msg.shortcut);
    }
		else if (msg.message == 'getSettings') {    
			port.postMessage({message: "getSettings", settings: getSettings()});
    }
  })
});
	
function getSettings() {
  value = JSON.stringify(localStorage);
  obj = JSON.parse(value);
  return obj;
}

	

			