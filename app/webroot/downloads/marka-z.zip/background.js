
chrome.browserAction.onClicked.addListener(function(tab) {
alert("marked");
 chrome.tabs.getSelected(null, function(tab) {

        var tabId = tab.id;
        tabUrl = tab.url;    
        tabTitle = tab.title;
      //  alert(tab.url);
        $.ajax({
    type: "POST",
    url: "http://www.marka-z.com/add",
    data: {url: tabUrl, title: tabTitle},
    success: function(data) {
      //alert(data);
    },
    error: function(XMLHttpRequest, textStatus, errorThrown) { 
    var bkg = chrome.extension.getBackgroundPage();
    bkg.console.log(errorThrown);
   //alert("Status: " + textStatus +"Error: " + errorThrown);
}
   }) ;
    });   

});